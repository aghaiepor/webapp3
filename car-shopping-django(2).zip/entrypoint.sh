#!/bin/bash
set -e # Exit immediately if a command exits with a non-zero status
set -x # Print commands and their arguments as they are executed

echo "Starting entrypoint script..."

# Ensure the media and staticfiles directories exist
mkdir -p /app/media
mkdir -p /app/staticfiles

echo "Making migrations (if needed)..."
python manage.py makemigrations cars

echo "Running database migrations..."
python manage.py migrate --noinput

# Add a small delay to ensure file system operations complete (less critical for SQLite, but harmless)
sleep 2

# Verify if the database file exists after migrations
if [ -f "/app/db.sqlite3" ]; then
  echo "Database file present:"
  ls -lh /app/db.sqlite3 # List file details
else
  echo "ERROR: /app/db.sqlite3 not found after migrate!"
  exit 1 # Exit if database file is not found
fi

echo "Collecting static files..."
python manage.py collectstatic --noinput

echo "Starting Django development server..."
exec python manage.py runserver 0.0.0.0:8000
